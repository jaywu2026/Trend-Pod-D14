"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const zlib = require("zlib");
const express = require("express");
const multer = require("multer");
const db = require("./lib/db");
const q = require("./lib/queries");
const ingest = require("./lib/ingest");
const fiscal = require("./lib/fiscal");

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 80 * 1024 * 1024 } });
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
// The gateway serves this app under a prefix (BASE_PATH) and strips it before
// forwarding, so container-internal routing stays at "/". But templates must
// still emit links/asset paths WITH the prefix, and as an absolute path from
// root — never a bare relative path like "admin/commit" or "./css/x.css".
// A bare relative path breaks the moment a POST response (upload/commit)
// renders content without redirecting: the browser's address bar sits at the
// POST target URL, and the next relative link on that page resolves against
// the WRONG directory (this is exactly what caused "Cannot POST
// /admin/admin/commit"). BASE_PATH-prefixed absolute paths sidestep that
// entirely since they don't depend on the current page's URL depth.
app.locals.href = (process.env.BASE_PATH || "") + "/";
app.use(express.urlencoded({ extended: false }));
app.use("/css", express.static(path.join(__dirname, "public/css")));
app.use("/js", express.static(path.join(__dirname, "public/js")));
app.use("/images", express.static(path.join(__dirname, "public/images")));

const usStatesGeo = fs.readFileSync(path.join(__dirname, "data/us_states_geo.json"), "utf8");

/* formatting helpers shared by all templates */
const fmt = n => Math.round(Number(n) || 0).toLocaleString("en-US");
const fmt$ = (n, dec) => "$" + Number(n || 0).toLocaleString("en-US",
  dec ? { minimumFractionDigits: dec, maximumFractionDigits: dec } : { maximumFractionDigits: 0 });
const pct = v => (v > 0 ? "+" : "") + (v * 100).toFixed(1) + "%";

let ready = false;
let seedError = null;
let seedAttempt = 0;
let seedStartedAt = Date.now();

async function seedWithRetry() {
  while (!ready) {
    seedAttempt++;
    const t0 = Date.now();
    try {
      console.log(`seed attempt ${seedAttempt} starting...`);
      await db.seed();
      ready = true;
      seedError = null;
      console.log(`seed attempt ${seedAttempt} succeeded in ${Date.now() - t0}ms`);
    } catch (e) {
      seedError = { message: e.message, stack: e.stack, at: new Date().toISOString(), attempt: seedAttempt };
      console.error(`seed attempt ${seedAttempt} FAILED after ${Date.now() - t0}ms:`, e);
      const wait = Math.min(5000 * seedAttempt, 30000);
      console.log(`retrying seed in ${wait}ms`);
      await new Promise(r => setTimeout(r, wait));
    }
  }
}

async function updatedLabel() {
  const { rows } = await db.pool.query(
    "SELECT to_char(max(business_date),'YYYY-MM-DD') d FROM item_daily");
  return rows[0].d || "—";
}
// "COOKWARE SETS" -> "Cookware Sets"; "—" -> "Uncategorized"
const catLabel = c => c === "—" ? "Uncategorized"
  : String(c).toLowerCase().replace(/(^|[\s/&-])\w/g, m => m.toUpperCase());
function locals(extra) {
  return { fmt, fmt$, pct, fiscal, catLabel, ...extra };
}
const guard = fn => async (req, res) => {
  try {
    if (!ready) {
      const elapsed = Math.round((Date.now() - seedStartedAt) / 1000);
      if (seedError) {
        return res.status(503).type("text/plain").send(
          `warming up — seed attempt ${seedError.attempt} failed after ${elapsed}s, retrying.\n\n` +
          `Last error: ${seedError.message}\n\n${seedError.stack}\n\n` +
          `(this text is meant to be copy-pasted back to Claude for diagnosis)`);
      }
      return res.status(503).type("text/plain").send(
        `warming up — seed in progress (${elapsed}s elapsed, attempt ${seedAttempt}), refresh in a few seconds`);
    }
    await fn(req, res);
  } catch (e) {
    console.error(e);
    res.status(500).send("<pre>" + (e.stack || e) + "</pre>");
  }
};

/* ---------------- pages ---------------- */
const summaryPage = guard(async (req, res) => {
  const data = await q.summaryData();
  const onHandTrend = await q.onHandTrendData();
  res.render("summary", locals({ data, onHandTrend, usStatesGeo, updatedLabel: await updatedLabel() }));
});
app.get("/", summaryPage);
app.get("/index.html", summaryPage);

for (const n of [1, 2, 3]) {
  app.get(`/side-${n}.html`, guard(async (req, res) => {
    const data = await q.sideData(n);
    res.render("side", locals({ data, updatedLabel: await updatedLabel() }));
  }));
}
app.get("/online.html", guard(async (req, res) => {
  const data = await q.onlineData();
  res.render("online", locals({ data, updatedLabel: await updatedLabel() }));
}));

/* client-rendered pages: inject live globals into converted static templates */
const aggPage = view => guard(async (req, res) => {
  const d = await q.storeAggData();
  res.render(view, locals({
    agg: d.agg, storeWeeks: d.storeWeeks, stores: d.stores,
    storeInstock: d.storeInstock, instockDate: d.instockDate,
    itemsFilter: d.items.map(i => ({ item_number: i.item_number, vendor_stock_id: i.vendor_stock_id,
      item_description: i.item_description, side: i.side })),
    updatedLabel: await updatedLabel(),
  }));
});
app.get("/top-stores.html", aggPage("topstores"));
app.get("/top-states.html", aggPage("topstates"));

app.get("/states.html", guard(async (req, res) => {
  const d = await q.storeAggData();
  const { rows: sw } = await db.pool.query("SELECT store_number, weeks_selling FROM store_weeks");
  const weeks = Object.fromEntries(sw.map(r => [r.store_number, r.weeks_selling]));
  const byState = {};
  const info = new Map(d.stores.map(s => [s.store_number, s]));
  const itemMeta = new Map(d.items.map(i => [i.item_number, i]));
  const perStore = new Map(), perStateItem = new Map();
  for (const r of d.agg) {
    const st = info.get(r.store_number); if (!st) continue;
    const key = st.state;
    let ps = perStore.get(r.store_number);
    if (!ps) { ps = { state: key, units: 0, sales: 0, selling: 0 }; perStore.set(r.store_number, ps); }
    ps.units += r.units; ps.sales += r.sales; ps.selling += 1;
    const k2 = key + "|" + r.item_number;
    const pi = perStateItem.get(k2) || { units: 0, sales: 0 };
    pi.units += r.units; pi.sales += r.sales; perStateItem.set(k2, pi);
  }
  for (const [storeNum, ps] of perStore) {
    const st = info.get(storeNum);
    const w = weeks[storeNum] || 1;
    (byState[ps.state] = byState[ps.state] || { stores: [], topItems: [] }).stores.push({
      store_number: storeNum, store_name: st.store_name,
      products_on_hand: 0, products_selling: ps.selling,
      total_units: ps.units, total_sales: +ps.sales.toFixed(2),
      units_per_week: ps.units / w, dollars_per_week: ps.sales / w,
    });
  }
  for (const [k2, v] of perStateItem) {
    const [state, itemStr] = k2.split("|");
    const it = itemMeta.get(Number(itemStr));
    if (!byState[state] || !it) continue;
    byState[state].topItems.push({ item_number: it.item_number, vendor_stock_id: it.vendor_stock_id,
      item_description: it.item_description, side: it.side,
      units: String(v.units), sales: v.sales.toFixed(2) });
  }
  for (const s of Object.values(byState)) {
    s.stores.sort((a, b) => b.total_sales - a.total_sales);
    s.topItems.sort((a, b) => +b.units - +a.units);
    s.topItems = s.topItems.slice(0, 15);
  }
  res.render("states", locals({ statesData: byState, updatedLabel: await updatedLabel() }));
}));

/* ---------------- admin ---------------- */
const staged = new Map(); // token -> {kind, filename, staged}
async function adminPage(res, extra) {
  const { rows: log } = await db.pool.query(
    "SELECT to_char(at,'YYYY-MM-DD HH24:MI') at, filename, kind, status, detail FROM upload_log ORDER BY id DESC LIMIT 25");
  const { rows: tables } = await db.pool.query(`
    SELECT c.relname name, c.reltuples::bigint rows FROM pg_class c
    JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE n.nspname = current_schema() AND c.relkind='r' ORDER BY 1`);
  const { rows: displayWeeks } = await db.pool.query(`
    SELECT w.fiscal_week fw, count(*)::int items, round(sum(w.sales_total),2) sales,
           m.spend, m.impressions
    FROM display_weekly w LEFT JOIN display_week_meta m ON m.fiscal_week = w.fiscal_week
    GROUP BY w.fiscal_week, m.spend, m.impressions ORDER BY 1`);
  res.render("admin", locals({ log, tables, displayWeeks, updatedLabel: await updatedLabel(), ...extra }));
}
app.get("/export/top-skus.xlsx", guard(async (req, res) => {
  const { buildTopSkusWorkbook } = require("./lib/export-xlsx");
  const data = await q.summaryData();
  const opts = {
    window: req.query.window, sort: req.query.sort, scope: req.query.scope,
    tiers: req.query.tiers ? String(req.query.tiers).split("|").filter(Boolean) : null,
    cats: req.query.cats ? String(req.query.cats).split("|").filter(Boolean) : null,
  };
  const buf = buildTopSkusWorkbook(data, opts);
  const tag = [opts.window || "total", opts.sort || "units", opts.scope || "all"].join("-");
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="top-skus-${tag}-${data.last}.xlsx"`);
  res.send(buf);
}));

app.get("/export/fc-inventory.xlsx", guard(async (req, res) => {
  const { buildFcInventoryWorkbook } = require("./lib/export-xlsx");
  const data = await q.onlineData();
  const buf = buildFcInventoryWorkbook(data.fcInventory);
  const stamp = data.fcInventory ? data.fcInventory.date : "no-data";
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="fc-inventory-${stamp}.xlsx"`);
  res.send(buf);
}));

app.get("/export/stores.xlsx", guard(async (req, res) => {
  const { buildStoresWorkbook } = require("./lib/export-xlsx");
  const d = await q.storeAggData();
  const side = req.query.side ? Number(req.query.side) : null;
  const item = req.query.item ? Number(req.query.item) : null;
  const buf = buildStoresWorkbook(d, { side, item });
  const tag = item ? `item-${item}` : side ? `side-${side}` : "all";
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="stores-481-${tag}.xlsx"`);
  res.send(buf);
}));

app.get("/admin", guard(async (req, res) => adminPage(res, {})));

app.post("/admin/upload", upload.single("file"), guard(async (req, res) => {
  const kind = req.body.kind || "store";
  const f = req.file;
  if (!f) return adminPage(res, { flash: { ok: false, error: "没有收到文件" } });
  const st = kind === "ecomm"
    ? await ingest.stageEcomm(f.buffer, f.originalname)
    : kind === "fcinv"
    ? await ingest.stageFcInventory(f.buffer, f.originalname, req.body.override_date || null)
    : kind === "ads"
    ? await ingest.stageAds(f.buffer, f.originalname)
    : kind === "display"
    ? await ingest.stageDisplay(f.buffer, f.originalname)
    : await ingest.stageStoreSales(f.buffer, f.originalname, req.body.override_date || null);
  if (st.error) {
    await db.pool.query("INSERT INTO upload_log(filename,kind,status,detail) VALUES($1,$2,'rejected',$3)",
      [f.originalname, kind, st.error]);
    return adminPage(res, { flash: { ok: false, error: st.error, problems: st.problems } });
  }
  const token = crypto.randomBytes(12).toString("hex");
  staged.set(token, { kind, filename: f.originalname, staged: st, at: Date.now() });
  for (const [t, v] of staged) if (Date.now() - v.at > 30 * 60 * 1000) staged.delete(t);
  if (kind === "display") {
    return adminPage(res, { preview: { ...st, token, filename: f.originalname, kind, perDate: {} } });
  }
  const perDate = kind === "ecomm"
    ? Object.fromEntries(st.dates.map(d => {
        const rows = st.recs.filter(r => r.date === d);
        return [d, { units: rows.reduce((s, r) => s + r.units, 0),
          sales: rows.reduce((s, r) => s + r.sales, 0),
          stores: 0, items: new Set(rows.map(r => r.item)).size }];
      }))
    : st.perDate;
  return adminPage(res, { preview: { ...st, perDate, token, filename: f.originalname, kind,
    rawRows: kind === "ecomm" ? st.recs.length : st.rawRows,
    rawStores: kind === "ecomm" ? 0 : st.rawStores } });
}));

app.post("/admin/display-move", guard(async (req, res) => {
  const from = parseInt(req.body.from_fw, 10), to = parseInt(req.body.to_fw, 10);
  if (!from || !to || from === to)
    return adminPage(res, { flash: { ok: false, error: "移动需要选择不同的源周和目标周" } });
  try {
    const out = await ingest.moveDisplayWeek(from, to);
    return adminPage(res, { flash: { ok: true, kind: "display", note: `Wk ${from} 的 ${out.moved} 个 item(含 spend/impressions)已移动到 Wk ${to}` } });
  } catch (e) {
    return adminPage(res, { flash: { ok: false, error: e.message } });
  }
}));

app.post("/admin/display-delete", guard(async (req, res) => {
  const fw = parseInt(req.body.fw, 10);
  if (!fw || req.body.confirm_text !== String(fw))
    return adminPage(res, { flash: { ok: false, error: "删除需要在确认框里输入该周的数字(如 29)" } });
  const out = await ingest.deleteDisplayWeek(fw);
  return adminPage(res, { flash: { ok: true, kind: "display", note: `Wk ${fw} 的 ${out.deleted} 个 item 已删除` } });
}));

app.post("/admin/commit", guard(async (req, res) => {
  const v = staged.get(req.body.token);
  if (!v) return adminPage(res, { flash: { ok: false, error: "预览已过期,请重新上传" } });
  staged.delete(req.body.token);
  if (!v.staged.ok) return adminPage(res, { flash: { ok: false, error: "校验未通过的文件不能合并", problems: v.staged.problems } });

  if (v.kind === "display") {
    const fw = parseInt(req.body.display_fw, 10);
    if (!fw) return adminPage(res, { flash: { ok: false, error: "缺少财周 — 请选择这份数据属于哪一周" } });
    if (req.body.week_confirm !== "1")
      return adminPage(res, { flash: { ok: false, error: `未勾选财周确认 — 请核对这份文件确实属于 Wk ${fw} 再勾选确认框提交` } });
    const num = x => { const n = parseFloat(String(x || "").replace(/[$,\s]/g, "")); return isNaN(n) ? null : n; };
    const out = await ingest.commitDisplay({ ...v.staged, filename: v.filename }, fw, {
      spend: num(req.body.display_spend),
      impressions: num(req.body.display_impressions),
      transactions: num(req.body.display_transactions),
    });
    return adminPage(res, { flash: { ok: true, kind: "display", displayResult: out } });
  }
  let overrideDates = req.body.override_dates || [];
  if (!Array.isArray(overrideDates)) overrideDates = [overrideDates];
  const selected = new Set([...v.staged.newDates, ...overrideDates]);
  const recs = v.staged.recs.filter(r => selected.has(r.date));
  if (!recs.length) {
    return adminPage(res, { flash: { ok: true, allSkipped: true, alreadyDates: v.staged.alreadyDates } });
  }
  const stagedFiltered = { ...v.staged, recs, dates: [...selected] };
  const out = v.kind === "ecomm"
    ? await ingest.commitEcomm(stagedFiltered, v.filename)
    : v.kind === "fcinv"
    ? await ingest.commitFcInventory(stagedFiltered, v.filename)
    : v.kind === "ads"
    ? await ingest.commitAds(stagedFiltered, v.filename)
    : await ingest.commitStoreSales(stagedFiltered, v.filename);
  return adminPage(res, { flash: { ok: true, kind: v.kind, verify: out.verify, mergedDates: [...selected].sort() } });
}));

app.get("/admin/export/:name.csv.gz", guard(async (req, res) => {
  const name = req.params.name.replace(/[^a-z0-9_]/gi, "");
  const { rows: ok } = await db.pool.query(
    `SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
     WHERE n.nspname=current_schema() AND c.relname=$1 AND c.relkind='r'`, [name]);
  if (!ok.length) return res.status(404).send("no such table");
  res.setHeader("Content-Type", "application/gzip");
  res.setHeader("Content-Disposition", `attachment; filename="${name}.csv.gz"`);
  const gz = zlib.createGzip();
  gz.pipe(res);
  const { rows } = await db.pool.query(`SELECT * FROM "${name}"`);
  if (rows.length) {
    const cols = Object.keys(rows[0]);
    gz.write(cols.join(",") + "\n");
    for (const r of rows)
      gz.write(cols.map(c => {
        const v = r[c] == null ? "" : String(r[c] instanceof Date ? r[c].toISOString().slice(0, 10) : r[c]);
        return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
      }).join(",") + "\n");
  }
  gz.end();
}));

app.get("/admin/handoff", guard(async (req, res) => {
  res.setHeader("Content-Type", "text/markdown; charset=utf-8");
  res.setHeader("Content-Disposition", 'attachment; filename="HANDOFF_TrendPod_Dashboard.md"');
  res.send(fs.readFileSync(path.join(__dirname, "HANDOFF.md"), "utf8"));
}));

app.post("/admin/sync-github", guard(async (req, res) => {
  const github = require("./lib/github-sync");
  try {
    const out = await github.syncToGithub();
    await db.pool.query("INSERT INTO upload_log(filename,kind,status,detail) VALUES($1,'github-sync',$2,$3)",
      [`${out.repo}@${out.branch}`, out.ok ? "committed" : "rejected",
        JSON.stringify(out.error ? { error: out.error, results: out.results } : { results: out.results })]);
    return adminPage(res, { githubFlash: out });
  } catch (e) {
    console.error(e);
    return adminPage(res, { githubFlash: { ok: false, error: e.message } });
  }
}));

app.get("/health", (req, res) => res.json({
  ok: true, ready, seedAttempt,
  elapsedSec: Math.round((Date.now() - seedStartedAt) / 1000),
  lastError: seedError ? seedError.message : null,
}));

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log("listening on", port);
  seedStartedAt = Date.now();
  seedWithRetry();
});
